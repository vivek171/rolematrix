package com.htc.rolematrix.constants;

import org.springframework.context.annotation.Configuration;

/**
 * Created by poovarasanv on 19/10/17.
 * Project : role-matrix
 */
@Configuration
public class TemplateConfig {

}
